const inputBtn = document.querySelector(".btnEl");
const inputEl = document.querySelector("input");
const unEl = document.querySelector(".unEl");

let myLead = ["https://www.w3schools.com/", "https://theprogrammingexpert.com/", "https://www.youtube.com"];

inputBtn.addEventListener("click", () => {
    myLead.push(inputEl.value)
    renderLeads(); 
}); 

function renderLeads(){
    let listItems =""; 
    for(i = 0; i < myLead.length; i++){
        // listItems += "<li><a href='" + myLead[i] + "' target='__blank'>"+ myLead[i] + "</a></li>";
        listItems +=   
        `<li>
            <a href="${myLead[i]}" target="__blank">${myLead[i]}</a>
        </li>`

    }
    unEl.innerHTML = listItems;     
    inputEl.value = "";
}